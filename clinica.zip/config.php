<?php
define('URLCOMPOSER', 'recursos/composer/');
define('URLCOMPOSER_VENDOR', 'recursos/composer/vendor/');
define('URLFW', 'public/fw/');
define('LIBS', 'libs/');
define('MODELS', './models/');
define('CONTROLLERS', '/controllers/');
define('VIEWS', '/views/');
define('BS', 'bussineslogic');

define('ALGORITMO', 'sha512');
define('ALGORITMO_CORREO', 'haval256,5');
define('HASHKEY', 'kassandra@2015');

define('SITE_KEY', '6LecD7sZAAAAANxIhcq2RizsKjnauhKa15KtzNDj');
define('SECRET_KEY', '6LecD7sZAAAAANjrpha6CE48XJUQFmoexgGt1nS8');

define('NOMBRE_SESSION', 'Sistema');
date_default_timezone_set('America/lima');
setlocale(LC_ALL, 'es_PE.UTF-8');
define('fecha', date("Y-m-d"));
define('hora', date("H:i:s"));
define('hora_', date("H:i"));
define('fecha_hora', date("Y-m-d H:i:s"));
