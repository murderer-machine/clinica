<?php
define('URL', $_ENV['API_URL']);
define('URL_WEBPACK',URL.'externos/');
//define('URL','/'); 

/*define('_DB_TYPE', 'mysql'); 
define('_DB_HOST', 'localhost'); 
define('_DB_USER', 'socia911_admin');  
define('_DB_PASS', 'kassandra@2015'); 
define('_DB_NAME', 'socia911_datos');*/

define('_DB_TYPE', 'mysql');
define('_DB_HOST', 'localhost');
define('_DB_USER', 'root');
define('_DB_PASS', '');
define('_DB_NAME', 'clinica');
//
define('NOMBRE_LOGO', 'logo.png');
define('NOMBRE_FAVICON', 'favicon.png');
define('NOMBRE_EMPRESA', 'Social Medic');
define('CORREO_EMPRESA', 'marcorodriguez2013@outlook.com');
define('URL_WEB_EMPRESA', 'comercial@socialmedic.com.pe');
//
define('AUTHOR', '');
define('DESCRIPTION', '');
define('KEYWORDS', '');
define('VERSION', '1.0');
