import React from 'react'
export const URL = '/'
//export const URL = 'https://demo.socialmedic.com.pe/'
export const DIRECCION = 'Calle Ricardo Palma cuadra 8 – Paucarpata'
export const CELULAR = '934588716 - 054751276'
export const CORREO = 'comercial@socialmedic.com.pe'
export const HORARIO = () => {
    return (
        <>
            Lunes - Viernes : 7:30 a.m. a 5:00 p.m.<br/>
            Sábado : 7:30 a.m. a 13:00 p.m.
        </>
    )
}